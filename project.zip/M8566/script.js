$(document).ready(function(){
    // Natural language execute button click event
    $("#nlExecute").click(function(){
        var naturalQuery = $("#nlInput").val().trim();
        if(naturalQuery === ""){
            alert("Please enter a natural language query");
            return;
        }
        // Show spinner
        $("#nlSpinner").show();
        $.ajax({
            url: "http://10.2.0.3:8888/nl2sql",
            type: "POST",
            data: JSON.stringify({ query: naturalQuery }),
            contentType: "application/json",
            success: function(response){
                $("#sqlInput").val(response.sql);
            },
            error: function(xhr){
                alert("Natural language conversion failed: " + xhr.responseText);
            },
            complete: function(){
                // Hide spinner
                $("#nlSpinner").hide();
            }
        });
    });

    // SQL execute button click event
    $("#sqlExecute").click(function(){
        var sqlQuery = $("#sqlInput").val().trim();
        if(sqlQuery === ""){
            alert("SQL cannot be empty");
            return;
        }
        // Show spinner
        $("#sqlSpinner").show();
        $.ajax({
            url: "http://10.2.0.3:8888/execute-sql",
            type: "POST",
            data: JSON.stringify({ query: sqlQuery }),
            contentType: "application/json",
            success: function(response){
                $("#displayArea").html("<pre>" + JSON.stringify(response, null, 2) + "</pre>");
            },
            error: function(xhr){
                $("#displayArea").html("<pre>Error: " + xhr.responseText + "</pre>");
            },
            complete: function(){
                // Hide spinner
                $("#sqlSpinner").hide();
            }
        });
    });
});
